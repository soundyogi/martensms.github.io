/*
 * @copyright 2008-2013 Christoph Martens
 * @author Christoph Martens (martensms)
 * @website www.martens.ms
 * All rights reserved.
 */

#ifndef _FOURIER_H
#define _FOURIER_H

int split_colors(u_char **pred, u_char **pgreen, u_char **pblue, 
		  u_char *img, int xdim, int ydim, int depth);

void fft_visible(int xdim, int ydim, fftw_complex *c, u_char *img,
		 double maxre, double maxim, double maxmod);
fftw_complex *fft_transform(int xdim, int ydim, unsigned char *data,
	       double *mre, double *mim, double *mmod);
void fft_filter(int xdim, int ydim, fftw_complex *data);
u_char *fft_transform_back(int xdim, int ydim, fftw_complex *data);
#endif

